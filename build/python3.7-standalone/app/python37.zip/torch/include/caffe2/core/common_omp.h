#ifndef CAFFE2_CORE_COMMON_OMP_H_
#define CAFFE2_CORE_COMMON_OMP_H_

#ifdef _OPENMP
#include <omp.h>
#endif // _OPENMP

#endif // CAFFE2_CORE_COMMON_OMP_H_
